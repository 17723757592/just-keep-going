window.onload = function()
{
    var topbtn = document.getElementById("btn");
    var timer = null;
    
    topbtn.onclick = function()
    {
        timer = setInterval( function()
        {
            var backtop = document.body.scrollTop;
            
            document.body.scrollTop -= 120;
            if(backtop ==0)
            {
                clearInterval(timer);
            }
        }, 30);
    }
}

