
function $(id){return document.getElementById(id);}
function changeImage(){
	var o=$("game");
	var index=o.selectedIndex;
	$("show").src=$("game").options[index].value; 
}